import Leftnav from "./Leftnav";

const Dashboard = () => {
  return (
    <div>
      <Leftnav></Leftnav>
    </div>
  );
};

export default Dashboard;
