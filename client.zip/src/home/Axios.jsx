const Axios = () => {
  return <div></div>;
};

export default Axios;
